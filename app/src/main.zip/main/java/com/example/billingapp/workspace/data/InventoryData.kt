package com.example.billingapp.workspace.data
data class InventoryPhone(val name: String, val units: Int, val specs: Map<String, String>? = null)
data class phonedata(val name:String)

data class  assdata(val name:String)
data class AccessoriesItem(val name: String , val units:Int, val price:Float)